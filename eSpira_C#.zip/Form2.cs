﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proiect_AI_Colaborativ_Zemax
{
    public partial class Form2: Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private readonly string[] _classNames_level1 = { "Aberrated", "Diffraction-Limited" }; 
        private readonly string[] _classNames_level2 = { "Spherical Aberration", "Coma", "Astigmatism", "None" }; 
        private readonly string[] _classNames_level3 = { "Astigmatism", "Chromatic Aberration", "Defocus", "Spherical Aberration", "None" }; 
        private readonly string[] _classNames_level4 = { "Astigmatism", "Coma", "Defocus", "Quatrefoil", "Spherical Aberration", "None" };

        public string Level1Selection { get; private set; }
        public string Level2Selection { get; private set; }
        public string Level3Selection { get; private set; }
        public string Level4Selection { get; private set; }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PopulateCombo(comboBox1, _classNames_level1);
            PopulateCombo(comboBox2, _classNames_level2);
            PopulateCombo(comboBox3, _classNames_level3);
            PopulateCombo(comboBox4, _classNames_level4);
        }

        private void PopulateCombo(ComboBox combo, string[] data)
        {
            combo.Items.AddRange(data);
            combo.DropDownStyle = ComboBoxStyle.DropDownList;

            if (combo.Items.Count > 0)
                combo.SelectedIndex = 0;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Level1Selection = comboBox1.SelectedItem?.ToString();
            Level2Selection = comboBox2.SelectedItem?.ToString();
            Level3Selection = comboBox3.SelectedItem?.ToString();
            Level4Selection = comboBox4.SelectedItem?.ToString();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text;


namespace Proiect_AI_Colaborativ_Zemax
{
    public partial class Form1 : Form
    {
        // Base folders selected by the 3 buttons
        private string _imageBaseFolder;
        private string _modelBaseFolder;
        private string _scriptBaseFolder;
        // 4 slots (level1..level4)
        private readonly string[] _imagePaths = new string[4];
        private readonly string[] _modelPaths = new string[4];
        private readonly string[] _scriptPaths = new string[4];
        private enum AssessInputMode
        {
            None,
            Predictions, // from Check Files
            Manual       // from Derive (manual selections)
        }

        private AssessInputMode _assessMode = AssessInputMode.None;
        // For manual input
        private string[] _manualSelections;   // [L1, L2, L3, L4]
        private bool _hasManualSelections;
        // Classes
        private readonly string[] _classNames_level1 =
        {
            "Aberrated",
            "Diffraction-Limited"
        };
        private readonly string[] _classNames_level2 =
        {
            "Spherical Aberration",
            "Coma",
            "Astigmatism"
        };
        private readonly string[] _classNames_level3 =
        {
            "Astigmatism",
            "Chromatic Aberration",
            "Defocus",
            "Spherical Aberration"
        };
        private readonly string[] _classNames_level4 =
        {
            "Astigmatism",
            "Coma",
            "Defocus",
            "Quatrefoil",
            "Spherical Aberration"
        };
        private PredictionResult[] _results = new PredictionResult[4];
        private const double CONF_THRESHOLD = 0.575;

        public Form1()
        {
            InitializeComponent();
        }

        private string PickFolder(string title, string initialPath = null)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                fbd.Description = title;
                fbd.ShowNewFolderButton = false;
                fbd.SelectedPath = !string.IsNullOrWhiteSpace(initialPath) && Directory.Exists(initialPath)
                    ? initialPath
                    : Environment.CurrentDirectory;
                return (fbd.ShowDialog() == DialogResult.OK) ? fbd.SelectedPath : null;
            }
        }

        private string GetSingleFileFromFolder(string folder, string[] allowedExts)
        {
            if (!Directory.Exists(folder)) return null;

            var files = Directory.GetFiles(folder)
                .Where(p => allowedExts.Contains(Path.GetExtension(p).ToLowerInvariant()))
                .OrderBy(p => p)
                .ToList();

            // If you expect exactly one file, pick the first
            return (files.Count >= 1) ? files[0] : null;
        }

        private string DumpSlots(string[] arr)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < arr.Length; i++)
                sb.AppendLine("Slot " + (i + 1) + ": " + (arr[i] ?? "(empty)"));
            return sb.ToString();
        }

        private AbType? MapPredictionToAberration(int levelIndex, string label)
        {
            if (string.IsNullOrWhiteSpace(label)) return null;

            string s = label.Trim().ToLowerInvariant();

            // Level 1 is just Aberrated / Under-Aberrated -> no specific aberration
            if (levelIndex == 0) return null;

            // Level 2 + 4
            if (s.Contains("spherical")) return AbType.Spherical;
            if (s.Contains("coma")) return AbType.Coma;
            if (s.Contains("astigmatism")) return AbType.Astigmatism;
            if (s.Contains("distortion")) return AbType.Distortion;
            if (s.Contains("field")) return AbType.FieldCurvature;

            // Level 3 has chromatic/defocus
            if (s.Contains("chromatic")) return AbType.AxialColor;      // treat as color family
            if (s.Contains("secondary")) return AbType.SecondarySpectrum;
            if (s.Contains("spherochrom")) return AbType.Spherochromatism;
            if (s.Contains("defocus")) return AbType.Defocus;

            // defocus isn’t in your matrix; ignore it for scoring
            return null;
        }
        private Dictionary<AbType, double> BuildActiveFromManual(string[] selections)
        {
            var active = new Dictionary<AbType, double>();

            for (int i = 0; i < 4; i++)
            {
                string label = selections[i];
                if (string.IsNullOrWhiteSpace(label)) continue;

                // "None" means no dominant aberration for that slot
                if (label.Equals("None", StringComparison.OrdinalIgnoreCase) ||
                    label.Equals("No Dominant Aberration", StringComparison.OrdinalIgnoreCase))
                    continue;

                AbType? ab = MapPredictionToAberration(i, label);
                if (ab == null) continue;

                // Manual pick => treat as full confidence
                double conf = 1.0;

                AbType key = ab.Value;
                if (!active.ContainsKey(key) || conf > active[key])
                    active[key] = conf;
            }

            return active;
        }

        private void btnOpenFolder1_Click(object sender, EventArgs e)
        {
            string folder = PickFolder("Select IMAGE base folder (contains subfolders 1..4)", Application.StartupPath);
            if (string.IsNullOrWhiteSpace(folder)) return;

            _imageBaseFolder = folder;

            // expects: base\1, base\2, base\3, base\4
            string[] exts = new[] { ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff" };

            for (int level = 1; level <= 4; level++)
            {
                string sub = Path.Combine(_imageBaseFolder, level.ToString());
                _imagePaths[level - 1] = GetSingleFileFromFolder(sub, exts);
            }

            RichTextBox.Text = "Loaded image slots:\n" + DumpSlots(_imagePaths);
        }

        private void btnOpenFolder2_Click(object sender, EventArgs e)
        {
            string folder = PickFolder("Select MODEL folder (contains 4 .keras files)", Application.StartupPath);
            if (string.IsNullOrWhiteSpace(folder)) return;

            _modelBaseFolder = folder;

            // Try to map by name containing level number, else alphabetical
            var keras = Directory.GetFiles(_modelBaseFolder, "*.keras").OrderBy(x => x).ToList();
            if (keras.Count == 0)
            {
                RichTextBox.Text = "No .keras files found in:\n" + _modelBaseFolder;
                return;
            }

            // Clear
            for (int i = 0; i < 4; i++) _modelPaths[i] = null;

            // 1) best-effort mapping by "level1".."level4" in filename
            for (int level = 1; level <= 4; level++)
            {
                string hit = keras.FirstOrDefault(p =>
                    Path.GetFileName(p).ToLowerInvariant().Contains("level" + level));
                if (!string.IsNullOrEmpty(hit))
                    _modelPaths[level - 1] = hit;
            }

            // 2) fill remaining slots by alphabetical
            int k = 0;
            for (int i = 0; i < 4; i++)
            {
                if (!string.IsNullOrEmpty(_modelPaths[i])) continue;
                while (k < keras.Count && _modelPaths.Contains(keras[k])) k++;
                if (k < keras.Count) _modelPaths[i] = keras[k++];
            }

            RichTextBox.Text = "Loaded model slots:\n" + DumpSlots(_modelPaths);
        }

        private void btnOpenFolder3_Click(object sender, EventArgs e)
        {
            string folder = PickFolder("Select SCRIPT folder (contains predict_one_level1..4.py)", Application.StartupPath);
            if (string.IsNullOrWhiteSpace(folder)) return;

            _scriptBaseFolder = folder;

            for (int level = 1; level <= 4; level++)
            {
                string script = Path.Combine(_scriptBaseFolder, "predict_one_level" + level + ".py");
                _scriptPaths[level - 1] = File.Exists(script) ? script : null;
            }

            RichTextBox.Text = "Loaded script slots:\n" + DumpSlots(_scriptPaths);
        }

        private async void btnCheckFile_Click(object sender, EventArgs e)
        {
            RichTextBox.Clear();
            _assessMode = AssessInputMode.Predictions;

            // Check that at least one image slot is filled
            bool anyImage = _imagePaths.Any(p => !string.IsNullOrWhiteSpace(p));
            if (!anyImage)
            {
                RichTextBox.Text = "No images loaded. Please load at least one image slot.";
                return;
            }

            // For each filled image slot, require a matching model and script
            for (int i = 0; i < 4; i++)
            {
                if (string.IsNullOrWhiteSpace(_imagePaths[i])) continue; // slot unused, skip

                if (string.IsNullOrWhiteSpace(_modelPaths[i]))
                { RichTextBox.Text = "Model slot " + (i + 1) + " is empty but image slot " + (i + 1) + " is filled."; return; }

                if (string.IsNullOrWhiteSpace(_scriptPaths[i]))
                { RichTextBox.Text = "Script slot " + (i + 1) + " is empty but image slot " + (i + 1) + " is filled."; return; }
            }

            btnCheckFile.Enabled = false;
            RichTextBox.Text = "Running predictions, please wait...";

            string[] outputs = new string[4];

            try
            {
                await Task.Run(() =>
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (string.IsNullOrWhiteSpace(_imagePaths[i]))
                        {
                            outputs[i] = "(skipped — no image)";
                            _results[i] = null; // leave empty
                            continue;
                        }

                        outputs[i] = RunPythonPredict(_modelPaths[i], _imagePaths[i], _scriptPaths[i]);
                        _results[i] = ParsePrediction(outputs[i]);
                    }
                });
            }
            finally
            {
                btnCheckFile.Enabled = true;
            }

            var sb = new StringBuilder();
            for (int i = 0; i < 4; i++)
            {
                sb.AppendLine("=== SLOT " + (i + 1) + " ===");
                if (string.IsNullOrWhiteSpace(_imagePaths[i]))
                {
                    sb.AppendLine("(slot not loaded — skipped)");
                }
                else
                {
                    sb.AppendLine("Model:  " + _modelPaths[i]);
                    sb.AppendLine("Image:  " + _imagePaths[i]);
                    sb.AppendLine("Script: " + _scriptPaths[i]);
                    sb.AppendLine();
                    sb.AppendLine(outputs[i]);
                }
                sb.AppendLine();
            }

            RichTextBox.Text = sb.ToString();
        }

        private string RunPythonPredict(string modelPath, string imagePath, string scriptPath)
        {
            string pythonExe = @"C:\Users\Radu\AppData\Local\Programs\Python\Python311\python.exe";        // CHANGE THIS
            //string scriptPath = @"C:\Users\Radu\Desktop\Proiect Master\OpenCV5-2\predict_one_level4.py";  // CHANGE THIS

            if (!File.Exists(pythonExe))
                return "ERROR: python.exe not found at:\n" + pythonExe;

            if (!File.Exists(scriptPath))
                return "ERROR: predict_one.py not found at:\n" + scriptPath;

            if (!File.Exists(modelPath))
                return "ERROR: model file not found:\n" + modelPath;

            if (!File.Exists(imagePath))
                return "ERROR: image file not found:\n" + imagePath;

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = pythonExe;
            psi.Arguments = "\"" + scriptPath + "\" --model \"" + modelPath + "\" --image \"" + imagePath + "\"";
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;

            // IMPORTANT: set working directory so `import pyimagesearch...` works
            psi.WorkingDirectory = Path.GetDirectoryName(scriptPath);

            Process p = new Process();
            p.StartInfo = psi;

            try
            {
                bool started = p.Start();
                if (!started)
                    return "ERROR: Process.Start() returned false (Python did not start).";

                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();

                p.WaitForExit();

                int exitCode = p.ExitCode;

                if (exitCode != 0)
                    return "PYTHON EXIT CODE " + exitCode + "\n\nSTDERR:\n" + stderr + "\n\nSTDOUT:\n" + stdout;

                // If TensorFlow prints warnings to stderr, you might still want them:
                if (!string.IsNullOrWhiteSpace(stderr))
                    return stdout + "\n\n[PYTHON STDERR]\n" + stderr;

                return stdout;
            }
            catch (Exception ex)
            {
                return "ERROR starting Python:\n" + ex.Message;
            }
            finally
            {
                p.Close();
                p.Dispose();
            }
        }

        private class PredictionResult
        {
            public int PredIndex;
            public string PredLabelRaw;
            public double Confidence;
            public string ProbsRaw;
        }

        private PredictionResult ParsePrediction(string output)
        {
            // Works even if output contains extra warnings/logs
            var r = new PredictionResult();
            r.PredIndex = -1;
            r.PredLabelRaw = "";
            r.Confidence = double.NaN;
            r.ProbsRaw = "";

            string[] lines = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            foreach (string line in lines)
            {
                if (line.StartsWith("pred_index="))
                {
                    int.TryParse(line.Substring("pred_index=".Length).Trim(), out r.PredIndex);
                }
                else if (line.StartsWith("pred_label="))
                {
                    r.PredLabelRaw = line.Substring("pred_label=".Length).Trim();
                }
                else if (line.StartsWith("confidence="))
                {
                    double.TryParse(line.Substring("confidence=".Length).Trim(),
                        System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out r.Confidence);
                }
                else if (line.StartsWith("probs="))
                {
                    r.ProbsRaw = line.Substring("probs=".Length).Trim();
                }
            }
            return r;
        }

        private string MakeTextTable(PredictionResult[] results)
        {
            string[][] labelSets = new string[][]
            {
                _classNames_level1,
                _classNames_level2,
                _classNames_level3,
                _classNames_level4
            };

            var sb = new StringBuilder();
            sb.AppendLine("Slot | Issue                   | Confidence  | Status");
            sb.AppendLine("---- | ----------------------- | ----------- | ------");

            for (int i = 0; i < results.Length; i++)
            {
                var r = results[i];

                // ERROR CONDITION
                // ERROR CONDITION  (replace the existing null/invalid check)
                if (r == null)
                {
                    sb.AppendLine(string.Format(
                        "{0,4} | {1,-23} | {2,11} | {3}",
                        i + 1,
                        "(not loaded)",
                        "----",
                        "SKIPPED"));
                    continue;
                }

                string[] labelsForSlot = (i < labelSets.Length) ? labelSets[i] : null;

                string label =
                    (labelsForSlot != null && r.PredIndex < labelsForSlot.Length)
                        ? labelsForSlot[r.PredIndex]
                        : "Unknown";

                string status;
                string finalLabel;

                if (r.Confidence < CONF_THRESHOLD)
                {
                    status = "GLANCE";
                    finalLabel = "No Dominant Aberration";
                }
                else
                {
                    status = "PARSE";
                    finalLabel = label;
                }

                sb.AppendLine(string.Format(
                    System.Globalization.CultureInfo.InvariantCulture,
                    "{0,4} | {1,-23} | {2,11:0.000000} | {3}",
                    i + 1,
                    finalLabel,
                    r.Confidence,
                    status));
            }

            return sb.ToString();
        }

        private void btnShowPred_Click(object sender, EventArgs e)
        {
            RichTextBox.Text = MakeTextTable(_results);
        }

        private void RichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private enum AbType
        {
            Spherical,
            Coma,
            Astigmatism,
            FieldCurvature,
            Distortion,
            Spherical5th,
            AxialColor,
            LateralColor,
            SecondarySpectrum,
            Spherochromatism,
            Defocus 
        }

        private class MatrixRow
        {
            public string Group;
            public string Parameter;
            public Dictionary<AbType, int> Scores; // 0/25/50/75

            // NEW
            public string Marker;       // e.g. "a", "b"
            public bool IsParenthesis;  // true if (a), false if a
        }

        private readonly List<MatrixRow> _matrix = new List<MatrixRow> // Zugge Matrix
        {
            // =========================
            // LENS PARAMETERS
            // =========================

            new MatrixRow {
                Group="Lens Parameters",
                Parameter="Lens Bending",
                Marker="a", IsParenthesis=true,   // 75 (a)
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,75},{AbType.Distortion,75},{AbType.Spherical5th,75},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Lens Parameters",
                Parameter="Power Splitting",
                Marker=null, IsParenthesis=false,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,25},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,50},{AbType.LateralColor,50},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,50}
                }
            },

            new MatrixRow {
                Group="Lens Parameters",
                Parameter="Power Combination",
                Marker="a", IsParenthesis=false,  // 75 a
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,75},{AbType.Spherical5th,0},
                    {AbType.AxialColor,50},{AbType.LateralColor,50},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,50}
                }
            },

            new MatrixRow {
                Group="Lens Parameters",
                Parameter="Distances",
                Marker="e", IsParenthesis=true,   // 75 (e)
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,25},{AbType.Astigmatism,50},
                    {AbType.FieldCurvature,75},{AbType.Distortion,50},{AbType.Spherical5th,75},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,50}
                }
            },

            new MatrixRow {
                Group="Lens Parameters",
                Parameter="Stop Position",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,75},{AbType.Astigmatism,75},
                    {AbType.FieldCurvature,50},{AbType.Distortion,0},{AbType.Spherical5th,50},
                    {AbType.AxialColor,25},{AbType.LateralColor,50},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            // =========================
            // MATERIAL
            // =========================

            new MatrixRow {
                Group="Material",
                Parameter="Refractive Index",
                Marker="b", IsParenthesis=true,   // 50 (b)
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,50},{AbType.Coma,50},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,50},{AbType.Spherical5th,50},
                    {AbType.AxialColor,50},{AbType.LateralColor,25},{AbType.SecondarySpectrum,25},{AbType.Spherochromatism,25}
                }
            },

            new MatrixRow {
                Group="Material",
                Parameter="Dispersion",
                Marker="i", IsParenthesis=true,   // 75 (i)
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,0},{AbType.Coma,0},{AbType.Astigmatism,0},
                    {AbType.FieldCurvature,0},{AbType.Distortion,0},{AbType.Spherical5th,0},
                    {AbType.AxialColor,75},{AbType.LateralColor,75},{AbType.SecondarySpectrum,75},{AbType.Spherochromatism,75}
                }
            },

            new MatrixRow {
                Group="Material",
                Parameter="Relative Partial Dispersion",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,0},{AbType.Coma,0},{AbType.Astigmatism,0},
                    {AbType.FieldCurvature,0},{AbType.Distortion,0},{AbType.Spherical5th,0},
                    {AbType.AxialColor,50},{AbType.LateralColor,50},{AbType.SecondarySpectrum,75},{AbType.Spherochromatism,75}
                }
            },

            // =========================
            // SPECIAL SURFACES
            // =========================

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="GRIN",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,50},
                    {AbType.FieldCurvature,50},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,50},{AbType.LateralColor,25},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="Cemented Surface",
                Marker="b", IsParenthesis=false,  // 75 b
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,75},{AbType.Spherical5th,75},
                    {AbType.AxialColor,50},{AbType.LateralColor,50},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,50}
                }
            },

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="Aplanatic Surface",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,50},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="Aspherical Surface",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,50},{AbType.Astigmatism,50},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="Mirror",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,75},
                    {AbType.FieldCurvature,75},{AbType.Distortion,75},{AbType.Spherical5th,75},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},{AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Special Surfaces",
                Parameter="Diffractive Surface",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,50},{AbType.Coma,50},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,75},{AbType.LateralColor,75},{AbType.SecondarySpectrum,75},{AbType.Spherochromatism,75}
                }
            }
        };

        private readonly List<MatrixRow> _matrix_model2 = new List<MatrixRow> // Kingslake-Smith Matrix
        {
            // =========================
            // LENS SHAPE / POWER
            // =========================

            new MatrixRow {
                Group="Lens Design",
                Parameter="Lens Bending",
                Marker="a", IsParenthesis=true,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,0},{AbType.Distortion,25},{AbType.Spherical5th,50},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,25}
                }
            },

            new MatrixRow {
                Group="Lens Design",
                Parameter="Power Redistribution",
                Marker="a", IsParenthesis=false,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,50},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,25},{AbType.LateralColor,25},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,50}
                }
            },

            new MatrixRow {
                Group="Lens Design",
                Parameter="Element Spacing",
                Marker="c", IsParenthesis=true,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,50},{AbType.Astigmatism,50},
                    {AbType.FieldCurvature,75},{AbType.Distortion,50},{AbType.Spherical5th,25},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,25}
                }
            },

            new MatrixRow {
                Group="Lens Design",
                Parameter="Stop Position Shift",
                Marker="c", IsParenthesis=false,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,75},{AbType.Astigmatism,75},
                    {AbType.FieldCurvature,50},{AbType.Distortion,75},{AbType.Spherical5th,25},
                    {AbType.AxialColor,0},{AbType.LateralColor,50},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            // =========================
            // MATERIAL CHOICE
            // =========================

            new MatrixRow {
                Group="Material",
                Parameter="Higher Index Glass",
                Marker="f", IsParenthesis=true,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,50},{AbType.Coma,25},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,50},
                    {AbType.AxialColor,50},{AbType.LateralColor,25},
                    {AbType.SecondarySpectrum,25},{AbType.Spherochromatism,25}
                }
            },

            new MatrixRow {
                Group="Material",
                Parameter="Dispersion Control",
                Marker="g", IsParenthesis=true,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,0},{AbType.Coma,0},{AbType.Astigmatism,0},
                    {AbType.FieldCurvature,0},{AbType.Distortion,0},{AbType.Spherical5th,0},
                    {AbType.AxialColor,75},{AbType.LateralColor,75},
                    {AbType.SecondarySpectrum,75},{AbType.Spherochromatism,75}
                }
            },

            // =========================
            // SYSTEM STRUCTURE
            // =========================

            new MatrixRow {
                Group="System Layout",
                Parameter="Symmetrical Layout",
                Marker="e", IsParenthesis=false,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,25},{AbType.Coma,75},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,75},{AbType.Spherical5th,0},
                    {AbType.AxialColor,0},{AbType.LateralColor,50},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="System Layout",
                Parameter="Cemented Doublet",
                Marker="g", IsParenthesis=false,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,50},{AbType.Coma,25},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,50},
                    {AbType.AxialColor,75},{AbType.LateralColor,50},
                    {AbType.SecondarySpectrum,50},{AbType.Spherochromatism,50}
                }
            },

            // =========================
            // SPECIAL SURFACES
            // =========================

            new MatrixRow {
                Group="Special Surface",
                Parameter="Aspheric Surface",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,75},{AbType.Coma,50},{AbType.Astigmatism,50},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,75},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            },

            new MatrixRow {
                Group="Special Surface",
                Parameter="Mirror Substitution",
                Marker=null,
                Scores=new Dictionary<AbType,int>{
                    {AbType.Spherical,50},{AbType.Coma,50},{AbType.Astigmatism,25},
                    {AbType.FieldCurvature,25},{AbType.Distortion,25},{AbType.Spherical5th,50},
                    {AbType.AxialColor,0},{AbType.LateralColor,0},
                    {AbType.SecondarySpectrum,0},{AbType.Spherochromatism,0}
                }
            }
        };

        private void btnAsses_Click(object sender, EventArgs e)
        {
            bool canUsePredictions = (_results != null && _results.Length >= 4 && _results.Any(r => r != null));
            bool canUseManual = (_hasManualSelections && _manualSelections != null && _manualSelections.Length >= 4);

            // Decide which mode to use (prefer last used, fallback to the other)
            AssessInputMode modeToUse = _assessMode;

            if (modeToUse == AssessInputMode.Manual && !canUseManual)
                modeToUse = canUsePredictions ? AssessInputMode.Predictions : AssessInputMode.None;

            if (modeToUse == AssessInputMode.Predictions && !canUsePredictions)
                modeToUse = canUseManual ? AssessInputMode.Manual : AssessInputMode.None;

            if (modeToUse == AssessInputMode.None)
            {
                RichTextBox.Text = "Run Check Files (AI) or Manual → Derive first.";
                return;
            }

            // Build active aberrations
            Dictionary<AbType, double> active;

            if (modeToUse == AssessInputMode.Manual)
            {
                active = BuildActiveFromManual(_manualSelections);
            }
            else
            {
                active = new Dictionary<AbType, double>();

                for (int i = 0; i < 4; i++)
                {
                    var r = _results[i];
                    if (r == null || r.PredIndex < 0 || double.IsNaN(r.Confidence)) continue;
                    if (r.Confidence < CONF_THRESHOLD) continue; // GLANCE -> treat as no dominant aberration

                    string[] labels = null;
                    if (i == 0) labels = _classNames_level1;
                    if (i == 1) labels = _classNames_level2;
                    if (i == 2) labels = _classNames_level3;
                    if (i == 3) labels = _classNames_level4;

                    if (labels == null || r.PredIndex >= labels.Length) continue;

                    string predLabel = labels[r.PredIndex];
                    AbType? ab = MapPredictionToAberration(i, predLabel);
                    if (ab == null) continue;

                    double conf = r.Confidence;
                    AbType key = ab.Value;
                    if (!active.ContainsKey(key) || conf > active[key])
                        active[key] = conf;
                }
            }

            if (active.Count == 0)
            {
                RichTextBox.Text = "No dominant aberration (all GLANCE/None/invalid).";
                return;
            }

            for (int i = 0; i < 4; i++)
            {
                var r = _results[i];
                if (r == null || r.PredIndex < 0 || double.IsNaN(r.Confidence)) continue;
                if (r.Confidence < CONF_THRESHOLD) continue; // GLANCE -> treat as no dominant aberration

                string[] labels = null;
                if (i == 0) labels = _classNames_level1;
                if (i == 1) labels = _classNames_level2;
                if (i == 2) labels = _classNames_level3;
                if (i == 3) labels = _classNames_level4;

                if (labels == null || r.PredIndex >= labels.Length) continue;

                string predLabel = labels[r.PredIndex];
                AbType? ab = MapPredictionToAberration(i, predLabel);
                if (ab == null) continue;

                // Keep the strongest confidence if repeated across levels
                double conf = r.Confidence;
                AbType key = ab.Value;
                if (!active.ContainsKey(key) || conf > active[key])
                    active[key] = conf;
            }

            if (active.Count == 0)
            {
                RichTextBox.Text = "No dominant aberration (all GLANCE or invalid).";
                return;
            }

            // Score each matrix row: sum(score% * confidenceWeight)
            // First compute raw scores
            var scoredRows = new List<Tuple<MatrixRow, double>>();

            if (radioButton1.Checked)
            {
                foreach (var row in _matrix)
                {
                    double total = 0.0;

                    foreach (var kv in active)
                    {
                        int pct = 0;
                        if (row.Scores != null && row.Scores.ContainsKey(kv.Key))
                            pct = row.Scores[kv.Key];

                        total += (pct / 100.0) * kv.Value;
                    }

                    scoredRows.Add(Tuple.Create(row, total));
                }
            }

            if (radioButton2.Checked)
            {
                foreach (var row in _matrix_model2)
                {
                    double total = 0.0;

                    foreach (var kv in active)
                    {
                        int pct = 0;
                        if (row.Scores != null && row.Scores.ContainsKey(kv.Key))
                            pct = row.Scores[kv.Key];

                        total += (pct / 100.0) * kv.Value;
                    }

                    scoredRows.Add(Tuple.Create(row, total));
                }
            }

            // Sort descending
            scoredRows = scoredRows.OrderByDescending(x => x.Item2).ToList();

            // Apply mutual exclusion rule
            var finalRows = new List<Tuple<MatrixRow, double>>();
            var usedMarkers = new Dictionary<string, bool>();
            // key = letter, value = IsParenthesis used

            foreach (var item in scoredRows)
            {
                var row = item.Item1;

                if (!string.IsNullOrEmpty(row.Marker))
                {
                    if (usedMarkers.ContainsKey(row.Marker))
                    {
                        bool existingType = usedMarkers[row.Marker];

                        // If conflict (a vs (a)) → skip
                        if (existingType != row.IsParenthesis)
                            continue;
                    }
                    else
                    {
                        usedMarkers[row.Marker] = row.IsParenthesis;
                    }
                }

                finalRows.Add(item);
            }

            // Print a compact ranked "table"
            var sb = new StringBuilder();
            sb.AppendLine("Active aberrations:");
            foreach (var kv in active.OrderByDescending(x => x.Value))
                sb.AppendLine(" - " + kv.Key + " (conf " + kv.Value.ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ")");

            sb.AppendLine();
            sb.AppendLine("Suggested knobs (ranked):");
            sb.AppendLine("Rank | Group            | Parameter         | Score");
            sb.AppendLine("-----+------------------+-------------------+------");

            int topN = Math.Min(10, finalRows.Count);
            for (int i = 0; i < topN; i++)
            {
                sb.AppendLine(string.Format(
                System.Globalization.CultureInfo.InvariantCulture,
                "{0,4} | {1,-16} | {2,-17} | {3,0:0.000}",
                i + 1,
                finalRows[i].Item1.Group,
                finalRows[i].Item1.Parameter,
                finalRows[i].Item2));
            }

            // --- Under-Aberrated Notice (supports both sources) ---
            string lvl1Label = null;

            if (modeToUse == AssessInputMode.Manual)
            {
                lvl1Label = _manualSelections[0];
            }
            else
            {
                if (_results[0] != null &&
                    _results[0].PredIndex >= 0 &&
                    !double.IsNaN(_results[0].Confidence) &&
                    _results[0].Confidence >= CONF_THRESHOLD &&
                    _results[0].PredIndex < _classNames_level1.Length)
                {
                    lvl1Label = _classNames_level1[_results[0].PredIndex];
                }
            }

            if (!string.IsNullOrEmpty(lvl1Label) &&
                lvl1Label.Equals("Diffraction-Limited", StringComparison.OrdinalIgnoreCase))
            {
                sb.AppendLine();
                sb.AppendLine("NOTICE:");
                sb.AppendLine("System classified as Diffraction-Limited.");
                sb.AppendLine("Any corrective change may not necessarily be effective,");
                sb.AppendLine("useful, or result in improved performance.");
            }

            RichTextBox.Text = sb.ToString();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Application is ready for use. Begin by:");
            sb.AppendLine("1> Loading images separated by folders with numerical identifiers (1,2,3,4)");
            sb.AppendLine("2> Loading model folder (just the folder)");
            sb.AppendLine("3> Loading the scripts folder (an Open-CV model for scripts)");
            sb.AppendLine();
            sb.AppendLine("Alternatively you can use load 'All Folders'. Or you can click Manual Load > filling check boxes.");
            sb.AppendLine();
            sb.AppendLine("You may want to note down the current MTF value in the text box above.");
            sb.AppendLine();
            sb.AppendLine("After that, either click Check Files or jump to Derive (if you used Manual Load). The application will run the AI");
            sb.AppendLine("to check for aberrations, and it may freeze the screen for several seconds.");
            sb.AppendLine();
            sb.AppendLine("If you have used Check Files, then click Show Predicates.");
            sb.AppendLine();
            sb.AppendLine("You should also select a model matrix after preference. Zugge is the most comprehensive of the two.");
            sb.AppendLine();
            sb.AppendLine("When ready, click Assess.");
            RichTextBox.Text = sb.ToString();
        }

        private void btnManual_Click(object sender, EventArgs e)
        {
            using (var f2 = new Form2())
            {
                if (f2.ShowDialog(this) == DialogResult.OK)
                {
                    _manualSelections = new[]
                    {
                        f2.Level1Selection,
                        f2.Level2Selection,
                        f2.Level3Selection,
                        f2.Level4Selection
                    };

                    _hasManualSelections = true;
                }
            }
        }

        private void btnDerive_Click(object sender, EventArgs e)
        {
            _assessMode = AssessInputMode.Manual;
            if (!_hasManualSelections || _manualSelections == null)
            {
                MessageBox.Show("Please run Manual selection first (btnManual).",
                                "No manual values",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                return;
            }

            RichTextBox.Text = MakeTextTableFromManual(_manualSelections);
        }

        private string MakeTextTableFromManual(string[] selections)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Slot | Issue                   | Confidence  | Status");
            sb.AppendLine("---- | ----------------------- | ----------- | ------");

            for (int i = 0; i < selections.Length; i++)
            {
                string issue = selections[i] ?? "Unknown";

                // Treat "None" (or "No Dominant Aberration") as low-confidence glance
                bool isNone =
                    issue.Equals("None", StringComparison.OrdinalIgnoreCase) ||
                    issue.Equals("No Dominant Aberration", StringComparison.OrdinalIgnoreCase);

                string status = isNone ? "GLANCE" : "MANUAL";
                string confText = isNone ? "----" : "1.000000";

                // Keep same alignment as your MakeTextTable
                sb.AppendLine(string.Format(
                    System.Globalization.CultureInfo.InvariantCulture,
                    "{0,4} | {1,-23} | {2,11} | {3}",
                    i + 1,
                    issue.Length > 23 ? issue.Substring(0, 23) : issue,
                    confText,
                    status));
            }

            return sb.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Application is ready for use. Begin by:");
            sb.AppendLine("1> Loading images separated by folders with numerical identifiers (1,2,3,4)");
            sb.AppendLine("2> Loading model folder (just the folder)");
            sb.AppendLine("3> Loading the scripts folder (an Open-CV model for scripts)");
            sb.AppendLine();
            sb.AppendLine("Alternatively you can use load 'All Folders'. Or you can click Manual Load > filling check boxes.");
            sb.AppendLine();
            sb.AppendLine("You may want to note down the current MTF value in the text box above.");
            sb.AppendLine();
            sb.AppendLine("After that, either click Check Files or jump to Derive (if you used Manual Load). The application will run the AI");
            sb.AppendLine("to check for aberrations, and it may freeze the screen for several seconds.");
            sb.AppendLine();
            sb.AppendLine("If you have used Check Files, then click Show Predicates.");
            sb.AppendLine();
            sb.AppendLine("You should also select a model matrix after preference. Zugge is the most comprehensive of the two.");
            sb.AppendLine();
            sb.AppendLine("When ready, click Assess.");
            RichTextBox.Text = sb.ToString();
        }

        private void btnOpenFolder4_Click(object sender, EventArgs e)
        {
            // One folder picker — user selects the root (e.g. C:\MyApp)
            string rootFolder = PickFolder("Select root folder (must contain Images, Models, Scripts subfolders)", Application.StartupPath);
            if (string.IsNullOrWhiteSpace(rootFolder)) return;

            // ─── SUBFOLDER NAMES — change these if yours differ ──────────────────────
            _imageBaseFolder = Path.Combine(rootFolder, "Images");
            _modelBaseFolder = Path.Combine(rootFolder, "Models");
            _scriptBaseFolder = Path.Combine(rootFolder, "Scripts");
            // ─────────────────────────────────────────────────────────────────────────

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"Root: {rootFolder}\n");

            // ── 1. IMAGES ─────────────────────────────────────────────────────────────
            string[] imgExts = { ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff" };
            bool imageBaseOk = Directory.Exists(_imageBaseFolder);

            for (int level = 1; level <= 4; level++)
            {
                if (imageBaseOk)
                {
                    string sub = Path.Combine(_imageBaseFolder, level.ToString());
                    _imagePaths[level - 1] = GetSingleFileFromFolder(sub, imgExts);
                }
                else
                {
                    _imagePaths[level - 1] = null;
                }
            }

            sb.AppendLine("── Image slots ──────────────────────────");
            if (!imageBaseOk)
                sb.AppendLine($"  [ERROR] Folder not found: {_imageBaseFolder}");
            else
                sb.Append(DumpSlots(_imagePaths));

            // ── 2. MODELS ─────────────────────────────────────────────────────────────
            for (int i = 0; i < 4; i++) _modelPaths[i] = null;

            bool modelBaseOk = Directory.Exists(_modelBaseFolder);

            if (modelBaseOk)
            {
                var keras = Directory.GetFiles(_modelBaseFolder, "*.keras")
                                     .OrderBy(x => x)
                                     .ToList();

                // Pass 1: map by "level1".."level4" in filename
                for (int level = 1; level <= 4; level++)
                {
                    string hit = keras.FirstOrDefault(p =>
                        Path.GetFileName(p).ToLowerInvariant().Contains("level" + level));
                    if (!string.IsNullOrEmpty(hit))
                        _modelPaths[level - 1] = hit;
                }

                // Pass 2: fill remaining slots alphabetically
                int k = 0;
                for (int i = 0; i < 4; i++)
                {
                    if (!string.IsNullOrEmpty(_modelPaths[i])) continue;
                    while (k < keras.Count && _modelPaths.Contains(keras[k])) k++;
                    if (k < keras.Count) _modelPaths[i] = keras[k++];
                }
            }

            sb.AppendLine("── Model slots ──────────────────────────");
            if (!modelBaseOk)
                sb.AppendLine($"  [ERROR] Folder not found: {_modelBaseFolder}");
            else
                sb.Append(DumpSlots(_modelPaths));

            // ── 3. SCRIPTS ────────────────────────────────────────────────────────────
            bool scriptBaseOk = Directory.Exists(_scriptBaseFolder);

            for (int level = 1; level <= 4; level++)
            {
                if (scriptBaseOk)
                {
                    string script = Path.Combine(_scriptBaseFolder,
                                                 $"predict_one_level{level}.py");
                    _scriptPaths[level - 1] = File.Exists(script) ? script : null;
                }
                else
                {
                    _scriptPaths[level - 1] = null;
                }
            }

            sb.AppendLine("── Script slots ─────────────────────────");
            if (!scriptBaseOk)
                sb.AppendLine($"  [ERROR] Folder not found: {_scriptBaseFolder}");
            else
                sb.Append(DumpSlots(_scriptPaths));

            RichTextBox.Text = sb.ToString();
        }
    }
}

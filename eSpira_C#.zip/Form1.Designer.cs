﻿namespace Proiect_AI_Colaborativ_Zemax
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenFolder1 = new System.Windows.Forms.Button();
            this.btnOpenFolder2 = new System.Windows.Forms.Button();
            this.btnOpenFolder3 = new System.Windows.Forms.Button();
            this.RichTextBox = new System.Windows.Forms.RichTextBox();
            this.btnCheckFile = new System.Windows.Forms.Button();
            this.btnShowPred = new System.Windows.Forms.Button();
            this.btnAsses = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnManual = new System.Windows.Forms.Button();
            this.btnDerive = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOpenFolder4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOpenFolder1
            // 
            this.btnOpenFolder1.Location = new System.Drawing.Point(8, 77);
            this.btnOpenFolder1.Name = "btnOpenFolder1";
            this.btnOpenFolder1.Size = new System.Drawing.Size(95, 23);
            this.btnOpenFolder1.TabIndex = 0;
            this.btnOpenFolder1.Text = "Image Folder";
            this.btnOpenFolder1.UseVisualStyleBackColor = true;
            this.btnOpenFolder1.Click += new System.EventHandler(this.btnOpenFolder1_Click);
            // 
            // btnOpenFolder2
            // 
            this.btnOpenFolder2.Location = new System.Drawing.Point(8, 107);
            this.btnOpenFolder2.Name = "btnOpenFolder2";
            this.btnOpenFolder2.Size = new System.Drawing.Size(95, 23);
            this.btnOpenFolder2.TabIndex = 1;
            this.btnOpenFolder2.Text = "Model Folder";
            this.btnOpenFolder2.UseVisualStyleBackColor = true;
            this.btnOpenFolder2.Click += new System.EventHandler(this.btnOpenFolder2_Click);
            // 
            // btnOpenFolder3
            // 
            this.btnOpenFolder3.Location = new System.Drawing.Point(8, 137);
            this.btnOpenFolder3.Name = "btnOpenFolder3";
            this.btnOpenFolder3.Size = new System.Drawing.Size(95, 23);
            this.btnOpenFolder3.TabIndex = 2;
            this.btnOpenFolder3.Text = "Scripts Folder";
            this.btnOpenFolder3.UseVisualStyleBackColor = true;
            this.btnOpenFolder3.Click += new System.EventHandler(this.btnOpenFolder3_Click);
            // 
            // RichTextBox
            // 
            this.RichTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RichTextBox.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RichTextBox.Location = new System.Drawing.Point(210, 78);
            this.RichTextBox.Name = "RichTextBox";
            this.RichTextBox.ReadOnly = true;
            this.RichTextBox.Size = new System.Drawing.Size(854, 528);
            this.RichTextBox.TabIndex = 4;
            this.RichTextBox.Text = "";
            this.RichTextBox.TextChanged += new System.EventHandler(this.RichTextBox_TextChanged);
            // 
            // btnCheckFile
            // 
            this.btnCheckFile.Location = new System.Drawing.Point(8, 196);
            this.btnCheckFile.Name = "btnCheckFile";
            this.btnCheckFile.Size = new System.Drawing.Size(95, 23);
            this.btnCheckFile.TabIndex = 5;
            this.btnCheckFile.Text = "Check Files";
            this.btnCheckFile.UseVisualStyleBackColor = true;
            this.btnCheckFile.Click += new System.EventHandler(this.btnCheckFile_Click);
            // 
            // btnShowPred
            // 
            this.btnShowPred.Location = new System.Drawing.Point(8, 225);
            this.btnShowPred.Name = "btnShowPred";
            this.btnShowPred.Size = new System.Drawing.Size(95, 23);
            this.btnShowPred.TabIndex = 10;
            this.btnShowPred.Text = "Show Predicates";
            this.btnShowPred.UseVisualStyleBackColor = true;
            this.btnShowPred.Click += new System.EventHandler(this.btnShowPred_Click);
            // 
            // btnAsses
            // 
            this.btnAsses.Location = new System.Drawing.Point(10, 319);
            this.btnAsses.Name = "btnAsses";
            this.btnAsses.Size = new System.Drawing.Size(95, 23);
            this.btnAsses.TabIndex = 11;
            this.btnAsses.Text = "AI Assess";
            this.btnAsses.UseVisualStyleBackColor = true;
            this.btnAsses.Click += new System.EventHandler(this.btnAsses_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(109, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(95, 20);
            this.textBox1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 15);
            this.label1.TabIndex = 13;
            this.label1.Text = "Initial MTF:";
            // 
            // btnManual
            // 
            this.btnManual.Location = new System.Drawing.Point(109, 78);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(95, 23);
            this.btnManual.TabIndex = 14;
            this.btnManual.Text = "Manual Load";
            this.btnManual.UseVisualStyleBackColor = true;
            this.btnManual.Click += new System.EventHandler(this.btnManual_Click);
            // 
            // btnDerive
            // 
            this.btnDerive.Location = new System.Drawing.Point(109, 225);
            this.btnDerive.Name = "btnDerive";
            this.btnDerive.Size = new System.Drawing.Size(95, 23);
            this.btnDerive.TabIndex = 15;
            this.btnDerive.Text = "Derive";
            this.btnDerive.UseVisualStyleBackColor = true;
            this.btnDerive.Click += new System.EventHandler(this.btnDerive_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(10, 348);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(95, 23);
            this.btnHelp.TabIndex = 17;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(6, 31);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(56, 17);
            this.radioButton1.TabIndex = 18;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Zugge";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(75, 31);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(100, 17);
            this.radioButton2.TabIndex = 19;
            this.radioButton2.Text = "Kingslake-Smith";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(10, 254);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(194, 59);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Matrix Model:";
            // 
            // btnOpenFolder4
            // 
            this.btnOpenFolder4.Location = new System.Drawing.Point(8, 166);
            this.btnOpenFolder4.Name = "btnOpenFolder4";
            this.btnOpenFolder4.Size = new System.Drawing.Size(95, 23);
            this.btnOpenFolder4.TabIndex = 21;
            this.btnOpenFolder4.Text = "All Folders";
            this.btnOpenFolder4.UseVisualStyleBackColor = true;
            this.btnOpenFolder4.Click += new System.EventHandler(this.btnOpenFolder4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 617);
            this.Controls.Add(this.btnOpenFolder4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnDerive);
            this.Controls.Add(this.btnManual);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnAsses);
            this.Controls.Add(this.btnShowPred);
            this.Controls.Add(this.btnCheckFile);
            this.Controls.Add(this.RichTextBox);
            this.Controls.Add(this.btnOpenFolder3);
            this.Controls.Add(this.btnOpenFolder2);
            this.Controls.Add(this.btnOpenFolder1);
            this.HelpButton = true;
            this.Name = "Form1";
            this.Text = "CollabAI ZEMAX [Alpha] - Pincus Spira";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenFolder1;
        private System.Windows.Forms.Button btnOpenFolder2;
        private System.Windows.Forms.Button btnOpenFolder3;
        private System.Windows.Forms.RichTextBox RichTextBox;
        private System.Windows.Forms.Button btnCheckFile;
        private System.Windows.Forms.Button btnShowPred;
        private System.Windows.Forms.Button btnAsses;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnManual;
        private System.Windows.Forms.Button btnDerive;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnOpenFolder4;
    }
}

